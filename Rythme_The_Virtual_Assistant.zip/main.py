import speech_recognition as sr
import playsound
import random
from gtts import gTTS
import webbrowser
import time as t
import os
import pyttsx3


class person:

    def __init__(self):
        self.name = ''

    def setName(self, name):
        self.name = name


class asis:

    def __init__(self, person):
        self.name = ''
        self.voice_data = ''
        self.r = sr.Recognizer()  # initialise the recognizer # listen for audio and convert to text
        self.person_obj = person

    def setName(self, name):
        self.name = name

    def there_exists(self, terms):
        for term in terms:
            term = term.lower()
            if term in self.voice_data:
                return True


    def record_audio(self, ask=""):

        with sr.Microphone() as source:  # mic as source
            if ask:
                self.engine_speak(ask)
            audio = self.r.listen(source, 5, 5)  # listen via mic
            print("Done Listening")

            try:
                self.voice_data = str(self.r.recognize_google(audio)).lower()  # convert audio to txt
                print(self.voice_data)
                return self.voice_data
            except sr.UnknownValueError as e0:  # error : recognizer didn't understand
                print(f'[SCRIPT ERROR] : {e0}')
                self.engine_speak("Sorry Sir, I didn't get that")
            except sr.RequestError as e1:
                self.engine_speak("Sorry the server is down")  # the recognizer isn't connected
                print(">>", self.voice_data.lower())
                print(f'[SCRIPT ERROR] : {e1}')
                return self.voice_data.lower()
            except Exception as e:
                print(f'[SCRIPT ERROR] : {e}')

            self.voice_data = ""
            return False

    def engine_speak(self, audio_string):
        audio_string = str(audio_string)
        gtts = gTTS(text=audio_string, lang='en')
        random_r = random.randint(1, 20000000)
        audio_file = 'audio' + str(random_r) + '.mp3'
        gtts.save(audio_file)  # save as mp3
        playsound.playsound(audio_file)  # ehlps to play the audio
        print(asis_obj.name + ":", audio_string)  # prints what app/web said
        os.remove(audio_file)

    def respond(self):

        self.voice_data = asis_obj.record_audio("fire your command boss:- ")
        print("Ok ! Let Me process ...")
        print("Executing : ", asis_obj.voice_data)

        # if changed_voice_data:
        #     self.voice_data = changed_voice_data

        # greetings
        if self.there_exists(["hello", "hi", "hey", "hola"]):
            greetings = ["hey, how can I help you" + self.person_obj.name, "how can i help you" + self.person_obj.name,
                         "hello" + self.person_obj.name]
            greet = greetings[random.randint(0, len(greetings) - 1)]
            self.engine_speak(greet)

        # name

        if self.there_exists(["What is your name?", "Tell me your name"]):
            if self.person_obj.name:
                self.engine_speak(
                    "I don't have a name, please give my name by saying command your name should be ")
            else:
                self.engine_speak("What's your name sir?")

        if self.there_exists(["My name is "]):
            person_name = self.voice_data.split("is")[-1].strip()
            self.engine_speak("okay sir I'll remember that your name is " + person_name())
            self.person_obj.setName(person_name)  # remembers name in person object

        if self.there_exists(["your name should be"]):
            asis_name = self.voice_data.split("be")[-1].strip()
            self.engine_speak("okay I'll remember that my name is " + asis_name)
            asis_obj.setName(asis_name)  # remembers name in asis object

        # greetings
        if self.there_exists(["how are you?", "how are you doing?"]):
            self.engine_speak("I'm very well, Thanks for asking" + self.person_obj.name)

        # time
        if self.there_exists(["what's the time", "tell me the time"]):
            time = t.ctime().split(" ")[3].split(":")[0:2]
            if time[0] == "00":
                hours = '12'
            else:
                hours = time[0]
                minutes = time[1]
                time = hours + "hours and" + minutes + "minutes"
                self.engine_speak(time)

        # search on Google
        if self.there_exists(["search for"]) and 'youtube' not in self.voice_data:
            search_term = self.voice_data.split("for")[-1]
            url = "https://google.com/search?q=" + search_term
            webbrowser.open(url)
            self.engine_speak("Here is what I found for" + search_term + "on google")

        # search youTube
        if self.there_exists(["youtube"]):
            search_term = self.voice_data.split("for")[-1]
            url = "https://www.youtube.com/results?search_query=" + search_term
            webbrowser.open(url)
            self.engine_speak("Here is what I found for" + search_term + "on youtube")

        # get to know stock prices
        if self.there_exists(["price of"]):
            search_term = self.voice_data.split("for")[-1]
            url = "https://google.com/search?q" + search_term
            webbrowser.get().open(url)
            self.engine_speak("here is what I found for" + search_term)

        # for music
        if self.there_exists(["play music on spotify", "song on spotify", "play song on spotify"]):
            search_term = self.voice_data.split("for")[-1]
            url = "https://open.spotify.com/search/" + search_term
            webbrowser.get().open(url)
            self.engine_speak("You are listening to" + search_term + "enjoy sir")

        if self.there_exists(["open paytm"]):
            search_term = self.voice_data.split("to")[-1]
            url = "https://paytm.com/" + search_term
            webbrowser.open(url)
            self.engine_speak("Here is what I found for" + search_term )

        # amazon
        if self.there_exists(["amazon", "open amazon"]):
            search_term = self.voice_data.split("for")[-1]
            url = "https://www.amazon.in"
            webbrowser.get().open(url)
            self.engine_speak("Here is what i found for" + search_term + "on amazon")

        if self.there_exists(["open zomato", "need some food delivered"]):
            search_term = self.voice_data.split("for")[-1]
            url = "https://www.zomato.com/"
            webbrowser.get().open(url)
            self.engine_speak("Here is what i found for" + search_term + "on zomato")

        if self.there_exists(["open dineout", "feeling hungry", "let's go out for food"]):
            search_term = self.voice_data.split("for")[-1]
            url = "https://www.dineout.co.in/"
            webbrowser.get().open(url)
            self.engine_speak("Here is what i found for" + search_term + "on dineout")

        # insta
        if self.there_exists(["open instagram", "instagram"]):
            search_term = self.voice_data.split("for")[-1]
            url = "https://www.instagram.com/"
            webbrowser.get().open(url)
            self.engine_speak("opening instagram")

        # twitter
        if self.there_exists(["twitter", "open twitter"]):
            search_term = self.voice_data.split("for")[-1]
            url = "https://twitter.com/"
            webbrowser.get().open(url)
            self.engine_speak("opening twitter")

        # weather
        if self.there_exists(
                ["weather", "tell me the weather report", "whats the condition outside", "weather report"]):
            search_term = self.voice_data.split("for")[-1]
            url = "https://www.google.com/search?client=safari&rls=en&q=weather&ie=UTF-8&oe=UTF-8"
            webbrowser.get().open(url)
            self.engine_speak("Here's all about today's weather")

        # gmail
        if self.there_exists(["gmail", "open mail", "check my mails"]):
            search_term = self.voice_data.split("for")[-1]
            url = "https://mail.google.com/mail/u/1/#inbox"
            webbrowser.get().open(url)
            self.engine_speak("you may check your email now")

        # game
        if self.there_exists(["game"]):
            self.voice_data = self.record_audio("choose among rock, paper, scissor")
            moves = ["rock", "paper", "scissor"]
            cmove = random.choice(moves)
            pmove = self.voice_data
            self.engine_speak("The computer chose" + " " + cmove)
            if pmove == cmove:
                self.engine_speak("The match is drawn")
            elif pmove == "rock" and cmove == "paper":
                self.engine_speak("Computer wins")
            elif pmove == "rock" and cmove == "scissor":
                self.engine_speak("Player wins")
            elif pmove == "paper" and cmove == "scissor":
                self.engine_speak("Computer wins")
            elif pmove == "paper" and cmove == "rock":
                self.engine_speak("Player wins")
            elif pmove == "scissor" and cmove == "paper":
                self.engine_speak("Player wins")
            elif pmove == "scissor" and cmove == "rock":
                self.engine_speak("Computer wins")

        if self.there_exists(["exit", "quit", "goodbye"]):
            self.engine_speak("Good bye, Sir")
            exit(0)

        self.respond()

        # return self.voice_data


if __name__ == '__main__':
    t.sleep(1)
    asis_obj = asis(person())
    asis_obj.name = 'Rythme'
    engine = pyttsx3.init()
    while (True):
        asis_obj.respond()
        break
